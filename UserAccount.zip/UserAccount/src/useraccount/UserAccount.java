package useraccount;

import javax.swing.JOptionPane;

public class UserAccount {
    private static String storedUsername = "";
    private static String storedPassword = "";
    private static int totalHours = 0;
   
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,"Welcome new or returning user.");
        
        boolean registrationSuccessful = registerUser();
        boolean loginSuccessful = loginUser();
            
        if (registrationSuccessful && loginSuccessful) {
            optionsMenu();
        } else {
            JOptionPane.showMessageDialog(null, "User registration or login failed.");
        }
    }
    
    public static boolean checkUserName(String username) {
        return username.length() >= 5 && username.contains("_");
    }

    public static boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*") && password.matches(".*[^A-Za-z0-9].*");
    }

    public static boolean registerUser() {
        String username = JOptionPane.showInputDialog("Enter username (must have an underscore and be no more than  5 characters):");
        String password = JOptionPane.showInputDialog("Enter password (at least 8 characters with a capital letter, a number, and a special character):");
        
        if (checkUserName(username) && checkPasswordComplexity(password)) {
            storedUsername = username;
            storedPassword = password;
            JOptionPane.showMessageDialog(null, "Registration successful!");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Registration failed. Please check username and password requirements.");
            return false;
        }
    }

    public static boolean loginUser() {
        String enteredUsername = JOptionPane.showInputDialog("Enter your username:");
        String enteredPassword = JOptionPane.showInputDialog("Enter your password:");
        
        if (enteredUsername.equals(storedUsername) && enteredPassword.equals(storedPassword)) {
            JOptionPane.showMessageDialog(null, "Login successful!");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Incorrect username or password.");
            return false;
        }
    }
    
    public static void optionsMenu() {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanBan.");
        String input;
        int choice;
        
        do {
            input = JOptionPane.showInputDialog(
                "Choose an option:\n1 - Add tasks\n2 - Show report\n3 - Quit");

            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid numeric choice (1, 2, or 3).");
                choice = 0;
            }

            switch (choice) {
                case 1:
                    JOptionPane.showMessageDialog(null, "You selected Option 1: Add tasks");
                    tasks();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "You selected Option 2: Show report");
                    JOptionPane.showMessageDialog(null, "Coming soon.");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "You selected Option 3: Exiting the program now");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option (1, 2, or 3).");
            }
        } while (choice != 3);
    }
    
    public static void tasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you wish to enter:"));
        
        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter the name of task " + (i + 1) + ":");
            String taskDescription = JOptionPane.showInputDialog("Enter a short description of task " + (i + 1) + " (not more than 50 characters):");
            String developerFirstName = JOptionPane.showInputDialog("Enter the first name of the developer assigned to task " + (i + 1) + ":");
            String developerLastName = JOptionPane.showInputDialog("Enter the last name of the developer assigned to task " + (i + 1) + ":");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the estimated duration of task " + (i + 1) + " in hours:"));

            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                i--;
                continue;
            } else {
                String taskID = createTaskID(taskName, i, developerLastName);
                String taskStatus = JOptionPane.showInputDialog("Enter the status of task " + (i + 1) + " (To Do, Done, or Doing):");

                String taskDetails = printTaskDetails(taskStatus, developerFirstName + " " + developerLastName, i, taskName, taskDescription, taskID, taskDuration);
                JOptionPane.showMessageDialog(null, taskDetails);

                totalHours += taskDuration;
            }
        }
        
        JOptionPane.showMessageDialog(null, "Total hours across all tasks: " + totalHours);
    }

    public static String createTaskID(String taskName, int taskNumber, String developerLastName) {
        //Stack Overflow. (n.d.). How can I place validating constraints on my method input parameters? [online] Available at: https://stackoverflow.com/questions/1809093/how-can-i-place-validating-constraints-on-my-method-input-parameters [Accessed 30 May 2024].
        String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + developerLastName.substring(developerLastName.length() - 3).toUpperCase();
        return taskID;
    }

    public static String printTaskDetails(String taskStatus, String developerDetails, int taskNumber, String taskName, String taskDescription, String taskID, int taskDuration) {
       //GeeksforGeeks. (2016). Method Overloading in Java. [online] Available at: https://www.geeksforgeeks.org/method-overloading-in-java/.
        String taskDetails = "Task Status: " + taskStatus + "\nDeveloper Details: " + developerDetails + "\nTask Number: " + taskNumber + "\nTask Name: " + taskName + "\nTask Description: " + taskDescription + "\nTask ID: " + taskID + "\nTask Duration: " + taskDuration + " hours";
        return taskDetails;
    }    
}

